package com.java.automation.lab.fall.antonyuk.core22.domain.horse;

public enum Gender {
    MARE,
    STALLION
}

package com.java.automation.lab.fall.antonyuk.core22.domain.person;

public enum Gender {
    MALE,
    FEMALE
}

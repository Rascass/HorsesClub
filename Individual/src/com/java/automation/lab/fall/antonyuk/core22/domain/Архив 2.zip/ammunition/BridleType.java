package com.java.automation.lab.fall.antonyuk.core22.domain.ammunition;

public enum BridleType {
    WESTERN,
    UNIVERSAL,
    WITHOUTSNAFFLE,
    SPANISH
}


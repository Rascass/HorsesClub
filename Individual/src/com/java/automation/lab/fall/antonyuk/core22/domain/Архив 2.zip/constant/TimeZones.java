package com.java.automation.lab.fall.antonyuk.core22.domain.constant;

public final class TimeZones {

    public static final String EUROPE_PARIS = "Europe/Paris";

    private TimeZones() {}
}

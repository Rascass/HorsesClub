package com.java.automation.lab.fall.antonyuk.core22.domain.person;

public enum PersonType {
    CLIENT,
    RIDER,
    EMPLOYEE
}

package com.java.automation.lab.fall.antonyuk.core22.domain.ammunition;

public enum SaddleType {
    UNIVERSAL,
    DRESSAGE,
    JUMPING,
    WESTERN
}

package com.java.automation.lab.fall.antonyuk.core22.domain.event;

public enum EventType {
    COMPETITION,
    MASTERCLASS,
    EXCURSION
}

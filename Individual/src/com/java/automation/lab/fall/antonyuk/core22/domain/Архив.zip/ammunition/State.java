package com.java.automation.lab.fall.antonyuk.core22.domain.ammunition;

public enum State {
    GOOD,
    NORMAL,
    BAD
}

package com.java.automation.lab.fall.antonyuk.core22.domain.ammunition;

public enum BridleSize {
    COB,
    FULL,
    FOAL
}
